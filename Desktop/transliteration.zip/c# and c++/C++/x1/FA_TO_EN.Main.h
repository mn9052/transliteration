﻿#pragma once

#include "Convertor.h"



namespace FA_TO_EN
{
	class Main : public System::Windows::Forms::Form
	{
		public:
		~Main()
		{
			this->Dispose(true);
		}


		private:
		void Finalize()
		{
			this->Dispose(false);
		}

	public:
		Main();

	private:
		void mainText_TextChanged(Object *sender, EventArgs *e);

		void translatedText_KeyPress(Object *sender, KeyPressEventArgs *e);


		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::IContainer *components;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		void Dispose(bool disposing);


		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent();


		System::Windows::Forms::TextBox *previewText;
		System::Windows::Forms::Button *newLine;
		System::Windows::Forms::TextBox *translatedText;
		System::Windows::Forms::TextBox *mainText;

	private:
		void InitializeInstanceFields();
	};
}
