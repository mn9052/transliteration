#include "FA_TO_EN.Main.h"


namespace FA_TO_EN
{

	Main::Main()
	{
		InitializeInstanceFields();
		InitializeComponent();
	}

	void Main::mainText_TextChanged(Object *sender, EventArgs *e)
	{
		if (translatedText->ForeColor == Color::Gray)
		{
			translatedText->ForeColor = Color::Black;
			translatedText->Clear();
		}

		if (mainText->Text->Length > 0)
			newLine->Enabled = true;
		else
			newLine->Enabled = false;


		previewText->Text = Convertor::ConvertToFinglish(mainText->Text->TrimStart(' '));
	}

	void Main::translatedText_KeyPress(Object *sender, KeyPressEventArgs *e)
	{
		e->Handled = true;
	}

	void Main::Dispose(bool disposing)
	{
		if (disposing && (components != 0))
		{
			delete components;
		}
		System::Windows::Forms::Form::Dispose(disposing);
	}

	void Main::InitializeComponent()
	{
		this->previewText = new System::Windows::Forms::TextBox();
		this->newLine = new System::Windows::Forms::Button();
		this->translatedText = new System::Windows::Forms::TextBox();
		this->mainText = new System::Windows::Forms::TextBox();
		this->SuspendLayout();
		// 
		// previewText
		// 
		this->previewText->Anchor = (static_cast<System::Windows::Forms::AnchorStyles>(((System::Windows::Forms::AnchorStyles::Top | System::Windows::Forms::AnchorStyles::Left) | System::Windows::Forms::AnchorStyles::Right)));
		this->previewText->Font = new System::Drawing::Font("Tahoma", 8.25F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, (static_cast<unsigned char>(0)));
		this->previewText->ForeColor = System::Drawing::Color::Black;
		this->previewText->Location = System::Drawing::Point(12, 39);
		this->previewText->Name = "previewText";
		this->previewText->RightToLeft = System::Windows::Forms::RightToLeft::Yes;
		this->previewText->Size = System::Drawing::Size(467, 21);
		this->previewText->TabIndex = 9;
		this->previewText->Text = "پیش نمایش متن";
		// 
		// newLine
		// 
		this->newLine->Enabled = false;
		this->newLine->FlatStyle = System::Windows::Forms::FlatStyle::Popup;
		this->newLine->Font = new System::Drawing::Font("Tahoma", 8.25F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, (static_cast<unsigned char>(0)));
		this->newLine->Location = System::Drawing::Point(398, 12);
		this->newLine->Name = "newLine";
		this->newLine->Size = System::Drawing::Size(86, 21);
		this->newLine->TabIndex = 8;
		this->newLine->Text = "برو به سر خط";
		this->newLine->UseVisualStyleBackColor = true;
		// 
		// translatedText
		// 
		this->translatedText->Font = new System::Drawing::Font("Arial", 12, (static_cast<System::Drawing::FontStyle>((System::Drawing::FontStyle::Bold | System::Drawing::FontStyle::Italic))), System::Drawing::GraphicsUnit::Point, (static_cast<unsigned char>(178)));
		this->translatedText->ForeColor = System::Drawing::Color::Gray;
		this->translatedText->Location = System::Drawing::Point(12, 66);
		this->translatedText->Multiline = true;
		this->translatedText->Name = "translatedText";
		this->translatedText->RightToLeft = System::Windows::Forms::RightToLeft::Yes;
		this->translatedText->ScrollBars = System::Windows::Forms::ScrollBars::Vertical;
		this->translatedText->Size = System::Drawing::Size(472, 211);
		this->translatedText->TabIndex = 7;
		this->translatedText->Text = "متن ترجمه شده اینجا قرار می گیرد (اینکار توسط برنامه انجام خواهد شد)";
		this->translatedText->KeyPress += new System::Windows::Forms::KeyPressEventHandler(this, &Main::translatedText_KeyPress);
		// 
		// mainText
		// 
		this->mainText->Anchor = (static_cast<System::Windows::Forms::AnchorStyles>(((System::Windows::Forms::AnchorStyles::Top | System::Windows::Forms::AnchorStyles::Left) | System::Windows::Forms::AnchorStyles::Right)));
		this->mainText->Font = new System::Drawing::Font("Tahoma", 8.25F, System::Drawing::FontStyle::Italic);
		this->mainText->ForeColor = System::Drawing::Color::Gray;
		this->mainText->Location = System::Drawing::Point(12, 12);
		this->mainText->Name = "mainText";
		this->mainText->Size = System::Drawing::Size(375, 21);
		this->mainText->TabIndex = 6;
		this->mainText->Text = "متن خود را اینجا تایپ کنید";
		this->mainText->TextChanged += new System::EventHandler(this, &Main::mainText_TextChanged);
		// 
		// Main
		// 
		this->setAutoScaleDimensions(System::Drawing::SizeF(6, 13));
		this->setAutoScaleMode(System::Windows::Forms::AutoScaleMode::Font);
		this->setClientSize(System::Drawing::Size(684, 332));
		this->getControls()->Add(this->previewText);
		this->getControls()->Add(this->newLine);
		this->getControls()->Add(this->translatedText);
		this->getControls()->Add(this->mainText);
		this->setName("Main");
		this->setText("Form1");
		this->ResumeLayout(false);
		this->PerformLayout();

	}

	void Main::InitializeInstanceFields()
	{
		components = 0;
	}
}
