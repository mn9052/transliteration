﻿#pragma once

#include "FA_TO_EN.Main.h"


namespace FA_TO_EN
{
	class Program
	{
		/// <summary>
	
		/// </summary>

//[STAThread]
		static void Main();
	};
}
