﻿#pragma once



namespace FA_TO_EN
{
	namespace Properties
	{


		class Resources
		{

		private:
			static System::Resources::ResourceManager *resourceMan;

			static System::Globalization::CultureInfo *resourceCulture;

		public:

			Resources();


			const static System::Resources::ResourceManager &getResourceManager() const;

			const static System::Globalization::CultureInfo &getCulture() const;
			static void setCulture(const System::Globalization::CultureInfo &value);
		};
	}
}
