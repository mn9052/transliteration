﻿#include "FA_TO_EN.Properties.Settings.h"

namespace FA_TO_EN
{
	namespace Properties
	{

Settings *Settings::defaultInstance = (static_cast<Settings*>(System::Configuration::ApplicationSettingsBase::Synchronized(new Settings())));

		const FA_TO_EN::Properties::Settings &Settings::getDefault() const
		{
			return defaultInstance;
		}
	}
}
