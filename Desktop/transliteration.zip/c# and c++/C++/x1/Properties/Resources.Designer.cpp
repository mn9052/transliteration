﻿#include "Resources.Designer.h"

namespace FA_TO_EN
{
	namespace Properties
	{

System::Resources::ResourceManager *Resources::resourceMan = 0;
System::Globalization::CultureInfo *Resources::resourceCulture = 0;

		Resources::Resources()
		{
		}

		const System::Resources::ResourceManager &Resources::getResourceManager() const
		{
			if ((resourceMan == 0))
			{
				System::Resources::ResourceManager *temp = new System::Resources::ResourceManager("FA_TO_EN.Properties.Resources", Resources::typeid::Assembly);
				resourceMan = temp;
			}
			return resourceMan;
		}

		const System::Globalization::CultureInfo &Resources::getCulture() const
		{
			return resourceCulture;
		}

		void Resources::setCulture(const System::Globalization::CultureInfo &value)
		{
			resourceCulture = value;
		}
	}
}
