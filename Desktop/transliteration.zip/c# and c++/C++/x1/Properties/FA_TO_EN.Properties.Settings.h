﻿#pragma once



namespace FA_TO_EN
{
	namespace Properties
	{
		class Settings : public System::Configuration::ApplicationSettingsBase
		{

		private:
			static Settings *defaultInstance;

		public:
			const static Settings &getDefault() const;
		};
	}
}
