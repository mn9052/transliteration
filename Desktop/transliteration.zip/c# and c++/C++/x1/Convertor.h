﻿#pragma once

#include <string>



namespace FA_TO_EN
{
	class Convertor
	{
	public:
		static std::string ConvertToFinglish(const std::string &sourceText);
	};
}
