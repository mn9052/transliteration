﻿#include "Program.h"



namespace FA_TO_EN
{

	void Program::Main()
	{
		Application::EnableVisualStyles();
		Application::SetCompatibleTextRenderingDefault(false);
		Application::Run(new Main());
	}
}
